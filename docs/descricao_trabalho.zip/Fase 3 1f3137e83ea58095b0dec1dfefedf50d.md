# Fase 3

Nome: Colheita de Dados e Insights - dados valiosos e maduros

[Atividades da Fase](Atividades%20da%20Fase%201f3137e83ea580a99e10e3d249e94d40.csv)