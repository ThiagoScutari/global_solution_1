# Challenge Cap 14

Descrição: A primeira técnica de aprendizado de máquina

### Objetivo

<aside>

Para essa atividade, você deverá analisar uma base de dados com informações de condições de solo e temperatura, relacionadas com o tipo de produto agrícola. Além da análise da base (visto no capítulo 13), você deverá construir alguns modelos preditivos e compará-los em termos da sua performance (abordado no capítulo 14).

</aside>

---

### Assets

<aside>

Cap 13

</aside>

[exemplos_limpeza_dados.csv](exemplos_limpeza_dados.csv)

<aside>

Cap 14

</aside>

[Atividade_Cap_14_produtos_agricolas.csv](Atividade_Cap_14_produtos_agricolas.csv)

[HTML_Cap_14_fertilizer_prediction.csv](HTML_Cap_14_fertilizer_prediction.csv)

<aside>

Google Colab

</aside>

[cap0_exemplo_inicial.ipynb](cap0_exemplo_inicial.ipynb)

[dados_credito.xlsx](dados_credito.xlsx)

[dados_credito_exemplo_inicial.csv](dados_credito_exemplo_inicial.csv)

---

### **Proposta de atividade:**

<aside>

Baseado no dataset apresentado, sua atividade consiste em:

- Fazer uma ***análise exploratória*** na base para se familiarizar com os dados;
- Fazer uma ***análise descritiva*** narrando os principais achados da base contendo no mínimo cinco gráficos;
- Encontrar o “perfil ideal” de solo/clima para as plantações, além de discorrer sobre como os três produtos distintos (à escolha do grupo) se comparam com esse perfil ideal. Por exemplo, preferem maior umidade e mais precipitação? Preferem mais calor e menos fósforo? Para esta parte se apoie em ***análises estatísticas e/ou visuais***;
- Desenvolver ***5 modelos preditivos*** (cada um com um algoritmo diferente, conforme visto no capítulo 14) que dadas as condições climáticas e de solo prevejam qual é o melhor produto agrícola a ser cultivado naquelas características. Esta parte da tarefa inclui seguir as boas práticas dos projetos de Machine Learning, bem como avaliar o modelo com métricas pertinentes ao problema.
</aside>

### Entregáveis:

<aside>

Entregue a atividade como um jupyter notebook contendo:

- Células de códigos executadas;
- Células de markdown organizando seu relatório e discorrendo textualmente sobre os achados a partir dos dados, e conclusões a respeito dos pontos fortes e limitações do trabalho;
- O nome do arquivo deve conter seu nome completo, RM, fase e capítulo, exemplo: “JoaoSantos_RM76332_fase3_cap2.ipynb”
</aside>