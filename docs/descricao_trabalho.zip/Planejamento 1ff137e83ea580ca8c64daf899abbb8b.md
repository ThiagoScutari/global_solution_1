# Planejamento

# PLANO de ESTUDOS SQL AVANÇADO

> **IMPORTANTE:** Este plano não aceita atalhos. Cada módulo deve ser completamente dominado antes de avançar. O objetivo é formar um especialista, não alguém que "se vira" com SQL.
> 
> 
> ---
> 

> **COMPROMISSO:** Ao final deste programa, você será capaz de não apenas recriar o código apresentado, mas de criar soluções ainda mais sofisticadas e robustas para qualquer problema de redistribuição ou lógica complexa em SQL.
> 
> 
> ---
> 

> **SUCESSO = DISCIPLINA + PRÁTICA DELIBERADA + ZERO COMPROMISSOS COM A MEDIOCRIDADE**
> 
> 
> ---
> 

---

## Objetivo: Dominar Redistribuição de Estoque e SQL Complexo

## Código raiz do curso

```sql
-- Script para redistribuir sobras para quebras na tabela QUEBRA_ESTOQUE
-- Versão: Redistribuição por PRODUTO (independente de cor e tamanho)
-- Autor: Claude AI
-- Data: 2025-05-26

-- Criação de tabela temporária para o resultado
IF OBJECT_ID('tempdb..#ResultadoRedistribuicao') IS NOT NULL
    DROP TABLE #ResultadoRedistribuicao;

CREATE TABLE #ResultadoRedistribuicao (
    Produto VARCHAR(50),
    Sortimento INT,
    CodCor VARCHAR(10),
    DescCor VARCHAR(50),
    Tamanho VARCHAR(10),
    VendaReal INT,
    VendaAberto INT,
    Estoque INT,
    Quebra INT,
    Sobras INT,
    SKU VARCHAR(50),
    SKU_Origem VARCHAR(50),
    SKU_Destino VARCHAR(50),
    Qtd INT,
    QuebraRemanescente INT,
    SobraRemanescente INT
);

-- Tabela temporária para controlar a redistribuição
IF OBJECT_ID('tempdb..#ControleRedistribuicao') IS NOT NULL
    DROP TABLE #ControleRedistribuicao;

CREATE TABLE #ControleRedistribuicao (
    SKU_Origem VARCHAR(50),
    SKU_Destino VARCHAR(50),
    QtdRedistribuida INT
);

-- Inserir dados base na tabela resultado
INSERT INTO #ResultadoRedistribuicao
SELECT 
    Produto, Sortimento, CodCor, DescCor, Tamanho,
    VendaReal, VendaAberto, Estoque, Quebra, Sobras, SKU,
    '-' as SKU_Origem,
    '-' as SKU_Destino,
    0 as Qtd,
    Quebra as QuebraRemanescente,
    Sobras as SobraRemanescente
FROM QUEBRA_ESTOQUE;

-- Cursor para processar redistribuição item por item
DECLARE @SKU_Deficit VARCHAR(50), @Deficit INT, @Produto VARCHAR(50);
DECLARE @SKU_Excesso VARCHAR(50), @Excesso INT, @QtdTransferencia INT;

DECLARE cursor_deficit CURSOR FOR
SELECT SKU, ABS(Sobras) as Deficit, Produto
FROM QUEBRA_ESTOQUE 
WHERE Sobras < 0
ORDER BY Produto, ABS(Sobras) DESC;

OPEN cursor_deficit;
FETCH NEXT FROM cursor_deficit INTO @SKU_Deficit, @Deficit, @Produto;

WHILE @@FETCH_STATUS = 0
BEGIN
    DECLARE @DeficitRestante INT = @Deficit;
    
    -- Cursor para encontrar excessos do mesmo produto (qualquer cor/tamanho)
    DECLARE cursor_excesso CURSOR FOR
    SELECT r.SKU, r.QuebraRemanescente
    FROM #ResultadoRedistribuicao r
    WHERE r.Produto = @Produto 
        AND r.QuebraRemanescente > 0
        AND r.SKU != @SKU_Deficit
    ORDER BY r.QuebraRemanescente DESC;
    
    OPEN cursor_excesso;
    FETCH NEXT FROM cursor_excesso INTO @SKU_Excesso, @Excesso;
    
    WHILE @@FETCH_STATUS = 0 AND @DeficitRestante > 0
    BEGIN
        -- Calcular quantidade a transferir
        SET @QtdTransferencia = CASE 
            WHEN @DeficitRestante <= @Excesso THEN @DeficitRestante
            ELSE @Excesso
        END;
        
        IF @QtdTransferencia > 0
        BEGIN
            -- Registrar a redistribuição
            INSERT INTO #ControleRedistribuicao VALUES (@SKU_Excesso, @SKU_Deficit, @QtdTransferencia);
            
            -- Atualizar destino (quem recebe) - registra de onde recebeu
            UPDATE #ResultadoRedistribuicao 
            SET SKU_Origem = @SKU_Excesso,
                Qtd = Qtd + @QtdTransferencia,
                SobraRemanescente = SobraRemanescente + @QtdTransferencia
            WHERE SKU = @SKU_Deficit;
            
            -- Atualizar origem (quem doa) - registra para onde doou
            UPDATE #ResultadoRedistribuicao 
            SET SKU_Destino = @SKU_Deficit,
                QuebraRemanescente = QuebraRemanescente - @QtdTransferencia
            WHERE SKU = @SKU_Excesso;
            
            SET @DeficitRestante = @DeficitRestante - @QtdTransferencia;
        END;
        
        FETCH NEXT FROM cursor_excesso INTO @SKU_Excesso, @Excesso;
    END;
    
    CLOSE cursor_excesso;
    DEALLOCATE cursor_excesso;
    
    FETCH NEXT FROM cursor_deficit INTO @SKU_Deficit, @Deficit, @Produto;
END;

CLOSE cursor_deficit;
DEALLOCATE cursor_deficit;

-- Ajustar casos onde houve múltiplas redistribuições para o mesmo SKU
UPDATE r1 SET 
    SKU_Origem = CASE 
        WHEN EXISTS (
            SELECT 1 FROM #ControleRedistribuicao cr2 
            WHERE cr2.SKU_Destino = r1.SKU AND cr2.QtdRedistribuida > 0
        ) THEN (
            SELECT TOP 1 cr.SKU_Origem 
            FROM #ControleRedistribuicao cr 
            WHERE cr.SKU_Destino = r1.SKU 
            ORDER BY cr.QtdRedistribuida DESC
        )
        ELSE '-'
    END,
    Qtd = COALESCE((
        SELECT SUM(cr.QtdRedistribuida) 
        FROM #ControleRedistribuicao cr 
        WHERE cr.SKU_Destino = r1.SKU
    ), 0)
FROM #ResultadoRedistribuicao r1;

-- Exibir resultado ordenado
SELECT * FROM #ResultadoRedistribuicao
ORDER BY Produto, Sortimento, CodCor, 
    CASE 
        WHEN Tamanho IN ('PP', 'XS') THEN 1
        WHEN Tamanho IN ('P', 'S') THEN 2
        WHEN Tamanho IN ('M') THEN 3
        WHEN Tamanho IN ('G', 'L') THEN 4
        WHEN Tamanho IN ('GG', 'XL') THEN 5
        WHEN Tamanho = '36' THEN 6
        WHEN Tamanho = '38' THEN 7
        WHEN Tamanho = '40' THEN 8
        WHEN Tamanho = '42' THEN 9
        WHEN Tamanho = '44' THEN 10
        WHEN Tamanho = '46' THEN 11
        WHEN Tamanho = '48' THEN 12
        WHEN Tamanho = '50' THEN 13
        WHEN Tamanho = '52' THEN 14
        WHEN Tamanho = '54' THEN 15
        ELSE 99
    END;

-- Relatório resumo da redistribuição
SELECT 
    'RESUMO DA REDISTRIBUIÇÃO' as Relatorio,
    COUNT(CASE WHEN Qtd > 0 THEN 1 END) as RegistrosAfetados,
    SUM(Qtd) as TotalRedistribuido,
    COUNT(CASE WHEN SobraRemanescente < 0 THEN 1 END) as DeficitsRestantes,
    COUNT(CASE WHEN QuebraRemanescente > 0 THEN 1 END) as ExcessosRestantes
FROM #ResultadoRedistribuicao;

-- Detalhamento das redistribuições realizadas
SELECT 
    'DETALHAMENTO DAS REDISTRIBUIÇÕES' as Relatorio,
    cr.SKU_Destino as [SKU que recebeu],
    cr.SKU_Origem as [SKU que doou],
    cr.QtdRedistribuida as [Quantidade],
    rd.Produto, rd.Sortimento, 
    rd.CodCor + ' ' + rd.DescCor as [Cor Origem],
    rd.Tamanho as [Tamanho Origem],
    rd2.CodCor + ' ' + rd2.DescCor as [Cor Destino],
    rd2.Tamanho as [Tamanho Destino]
FROM #ControleRedistribuicao cr
INNER JOIN #ResultadoRedistribuicao rd ON cr.SKU_Origem = rd.SKU
INNER JOIN #ResultadoRedistribuicao rd2 ON cr.SKU_Destino = rd2.SKU
WHERE cr.QtdRedistribuida > 0
ORDER BY rd.Produto, rd.Sortimento, cr.QtdRedistribuida DESC;

-- Relatório por produto mostrando saldo antes e depois
SELECT 
    'SALDO POR PRODUTO' as Relatorio,
    r.Produto,
    SUM(qe.Quebra) as QuebraOriginal,
    SUM(qe.Sobras) as SobraOriginal,
    SUM(r.QuebraRemanescente) as QuebraFinal,
    SUM(r.SobraRemanescente) as SobraFinal,
    SUM(qe.Sobras) - SUM(r.SobraRemanescente) as DiferencaSobras
FROM #ResultadoRedistribuicao r
INNER JOIN QUEBRA_ESTOQUE qe ON r.SKU = qe.SKU
GROUP BY r.Produto
ORDER BY r.Produto;

-- Opcional: Atualizar a tabela original com os novos valores
/*
UPDATE qe SET 
    Quebra = r.QuebraRemanescente,
    Sobras = r.SobraRemanescente
FROM QUEBRA_ESTOQUE qe
INNER JOIN #ResultadoRedistribuicao r ON qe.SKU = r.SKU
WHERE r.Qtd > 0 OR r.QuebraRemanescente != qe.Quebra OR r.SobraRemanescente != qe.Sobras;
*/

-- Limpeza
DROP TABLE #ResultadoRedistribuicao;
DROP TABLE #ControleRedistribuicao;
```

---

# **FASE 1: FUNDAMENTOS SÓLIDOS (40-60 horas)**

## **Módulo 1.1: SQL Básico Revisado (15h)**

**Objetivo:** Base impecável para estruturas avançadas

**Tópicos Obrigatórios:**

- **DDL (Data Definition Language)**
    - CREATE TABLE com todas as constraints
    - ALTER TABLE (modificações de estrutura)
    - DROP, TRUNCATE vs DELETE
    - Tipos de dados avançados (VARCHAR vs CHAR, precisão de números)
- **DML (Data Manipulation Language)**
    - INSERT com múltiplas estratégias
    - UPDATE com JOINs e subconsultas
    - DELETE com condições complexas
    - MERGE (upsert operations)

**Exercícios Práticos:**

1. Criar sistema de estoque básico (5 tabelas relacionadas)
2. Implementar 20 consultas progressivamente complexas
3. Manipular dados com pelo menos 10.000 registros

**Critério de Aprovação:** Executar qualquer comando DDL/DML sem consultar documentação

---

## **Módulo 1.2: JOINs e Subconsultas Avançadas (15h)**

**Objetivo:** Domínio total de relacionamentos complexos

**Tópicos Essenciais:**

- **Tipos de JOIN**
    - INNER, LEFT, RIGHT, FULL OUTER
    - CROSS JOIN e suas aplicações
    - SELF JOIN para hierarquias
    - JOINs múltiplos com performance
- **Subconsultas Avançadas**
    - Correlated vs Non-correlated subqueries
    - EXISTS vs IN vs ANY/ALL
    - Common Table Expressions (CTEs)
    - CTEs recursivas para hierarquias

**Exercícios Obrigatórios:**

1. Criar consulta com 5+ JOINs diferentes
2. Implementar 3 CTEs recursivas
3. Resolver 15 problemas de subconsultas correlacionadas
4. Otimizar consultas com EXPLAIN PLAN

**Critério de Aprovação:** Resolver qualquer problema de relacionamento em <5 minutos

---

## **Módulo 1.3: Funções Analíticas e Agregação (10h)**

**Objetivo:** Window functions e análises estatísticas

**Conteúdo Crítico:**

- **Window Functions**
    - ROW_NUMBER(), RANK(), DENSE_RANK()
    - LAG(), LEAD() para comparações temporais
    - SUM(), AVG() com OVER()
    - PARTITION BY vs GROUP BY
- **Funções de Agregação Avançadas**
    - GROUP BY com ROLLUP, CUBE, GROUPING SETS
    - HAVING com condições complexas
    - Agregações condicionais com CASE

**Exercícios Práticos:**

1. Análise de vendas por período com ranking
2. Comparações mês a mês usando LAG/LEAD
3. Relatórios com subtotais e totais gerais
4. Identificação de outliers estatísticos

**Critério de Aprovação:** Criar relatórios analíticos sem assistência

---

# **FASE 2: ESTRUTURAS DE CONTROLE (50-70 horas)**

## **Módulo 2.1: Variáveis e Controle de Fluxo (20h)**

**Objetivo:** Programação procedural em SQL

**Fundamentais:**

- **Declaração e Uso de Variáveis**
    - DECLARE para diferentes tipos
    - SET vs SELECT para atribuição
    - Escopo de variáveis (local vs global)
    - Variáveis de tabela vs tabelas temporárias
- **Estruturas Condicionais**
    - IF...ELSE aninhados
    - CASE simples vs searched
    - Condições complexas com múltiplos operadores
    - Tratamento de NULLs em condições
- **Loops e Iteração**
    - WHILE loops com condições de saída
    - BREAK e CONTINUE
    - Loops aninhados
    - Contadores e acumuladores

**Exercícios Intensivos:**

1. Implementar calculadora com todas as operações
2. Criar sistema de aprovação com múltiplos níveis
3. Processamento batch com controle de erro
4. Simulação de distribuição probabilística

**Critério de Aprovação:** Escrever qualquer algoritmo procedural fluentemente

---

## **Módulo 2.2: Tabelas Temporárias e Variáveis de Tabela (15h)**

**Objetivo:** Gerenciamento eficiente de dados temporários

**Conceitos Vitais:**

- **Tipos de Tabelas Temporárias**
    - #temp (local) vs ##temp (global)
    - @table variables
    - Table-valued parameters
    - Memory-optimized temp tables
- **Gerenciamento de Ciclo de Vida**
    - Criação e destruição automática
    - Escopo e visibilidade
    - Performance: quando usar cada tipo
    - Indexação em tabelas temporárias
- **Padrões de Uso Avançados**
    - Staging tables para ETL
    - Resultados intermediários em processos complexos
    - Cache de dados para performance
    - Controle de transações com temp tables

**Exercícios Obrigatórios:**

1. Sistema ETL completo com staging
2. Cache de relatórios com refresh automático
3. Processamento em lotes com checkpoint
4. Comparação de performance entre tipos

**Critério de Aprovação:** Escolher e implementar o tipo correto para qualquer cenário

---

## **Módulo 2.3: Cursors - Teoria e Prática (15h)**

**Objetivo:** Processamento linha a linha eficiente

**Conhecimento Profundo:**

- **Tipos de Cursors**
    - FORWARD_ONLY vs SCROLL
    - STATIC vs DYNAMIC vs KEYSET
    - READ_ONLY vs UPDATABLE
    - LOCAL vs GLOBAL scope
- **Ciclo de Vida do Cursor**
    - DECLARE com todas as opções
    - OPEN e verificação de erros
    - FETCH com @@FETCH_STATUS
    - CLOSE e DEALLOCATE obrigatórios
- **Cursors Aninhados**
    - Estrutura de loops aninhados
    - Gerenciamento de múltiplos cursors
    - Performance e memory management
    - Alternativas set-based quando possível

**Exercícios Rigorosos:**

1. Processamento hierárquico com cursors aninhados
2. Migração de dados com transformação complexa
3. Auditoria linha por linha com log detalhado
4. Comparação cursor vs set-based (performance)

**Critério de Aprovação:** Implementar qualquer lógica linha-a-linha sem bugs

---

# **FASE 3: STORED PROCEDURES E FUNCTIONS (40-60 horas)**

## **Módulo 3.1: Stored Procedures Avançadas (25h)**

**Objetivo:** Encapsulamento de lógica complexa

**Competências Essenciais:**

- **Estrutura e Sintaxe**
    - CREATE PROCEDURE com parâmetros
    - INPUT, OUTPUT, INPUT/OUTPUT parameters
    - Valores default e parâmetros opcionais
    - Return values e códigos de erro
- **Tratamento de Erros**
    - TRY...CATCH blocks
    - @@ERROR e ERROR_* functions
    - RAISERROR customizado
    - Transações e rollback automático
- **Performance e Otimização**
    - SET NOCOUNT ON
    - Planos de execução e recompilação
    - Parameter sniffing issues
    - Statistics e indexing hints

**Projetos Práticos:**

1. Sistema completo de CRUD com auditoria
2. Procedure de relatório com múltiplos formatos
3. Batch processing com recovery automático
4. API de negócio com validações complexas

**Critério de Aprovação:** Criar procedures robustas com tratamento completo de erros

---

## **Módulo 3.2: User-Defined Functions (15h)**

**Objetivo:** Reutilização de código e modularização

**Tipos e Aplicações:**

- **Scalar Functions**
    - Cálculos matemáticos complexos
    - Formatação e manipulação de strings
    - Conversões de data e validações
    - Deterministic vs non-deterministic
- **Table-Valued Functions**
    - Inline vs multi-statement
    - Parameterização de consultas
    - Performance comparada a views
    - Composição de functions

**Exercícios Específicos:**

1. Biblioteca de functions matemáticas
2. Functions de validação de dados
3. Transformadores de formato (JSON, XML)
4. Functions de análise temporal

**Critério de Aprovação:** Criar functions reutilizáveis para qualquer domínio

---

# **FASE 4: LÓGICA DE NEGÓCIO COMPLEXA (60-80 horas)**

## **Módulo 4.1: Algoritmos de Redistribuição (30h)**

**Objetivo:** Dominar a lógica central do código apresentado

**Conceitos Fundamentais:**

- **Teoria da Redistribuição**
    - Algoritmos de balanceamento de carga
    - Matching de oferta e demanda
    - Otimização de recursos escassos
    - Fairness vs efficiency
- **Implementação Prática**
    - Identificação de déficits e excessos
    - Priorização de transferências
    - Controle de estado durante processo
    - Rastreabilidade de movimentações
- **Padrões de Código**
    - Separação de dados e controle
    - Tabelas de auditoria automáticas
    - Checkpoints e rollback points
    - Validação de integridade contínua

**Exercícios Progressivos:**

1. Redistribuição simples (1 dimensão)
2. Redistribuição com prioridades
3. Redistribuição multi-dimensional (cor, tamanho)
4. Redistribuição com constraints de negócio
5. Otimização de custos de transferência

**Critério de Aprovação:** Implementar qualquer algoritmo de redistribuição do zero

---

## **Módulo 4.2: Controle de Estado e Transações (20h)**

**Objetivo:** Garantir consistência em processos complexos

**Competências Avançadas:**

- **Transaction Management**
    - BEGIN, COMMIT, ROLLBACK estratégicos
    - Isolation levels e deadlocks
    - Distributed transactions
    - Savepoints para checkpoints
- **State Tracking**
    - Tabelas de controle de processo
    - Status flags e timestamps
    - Versionamento de dados
    - Audit trails completos
- **Error Recovery**
    - Rollback parcial inteligente
    - Reprocessamento automático
    - Data consistency validation
    - Manual intervention points

**Projetos Críticos:**

1. Sistema de pedidos com múltiplas aprovações
2. Processamento de folha de pagamento
3. Reconciliação bancária automática
4. Sistema de inventory com reservas

**Critério de Aprovação:** Garantir 100% de consistência em qualquer processo

---

## **Módulo 4.3: Reporting e Analytics (10h)**

**Objetivo:** Transformar dados em insights

**Skills Necessárias:**

- **Relatórios Dinâmicos**
    - SQL dinâmico com sp_executesql
    - Pivot tables programáticas
    - Drill-down automático
    - Export para múltiplos formatos
- **Análises Estatísticas**
    - Percentis e quartis
    - Correlações e tendências
    - Outlier detection
    - Forecasting básico

**Entregáveis:**

1. Dashboard completo do processo de redistribuição
2. Relatório de performance histórica
3. Alertas automáticos para anomalias
4. KPIs em tempo real

**Critério de Aprovação:** Criar qualquer relatório solicitado em <30 minutos

---

# **FASE 5: OTIMIZAÇÃO E DEBUGGING (30-40 horas)**

## **Módulo 5.1: Performance Tuning (20h)**

**Objetivo:** Código rápido e eficiente

**Técnicas Avançadas:**

- **Index Strategy**
    - Clustered vs non-clustered
    - Covering indexes
    - Filtered indexes
    - Index maintenance
- **Query Optimization**
    - Execution plan analysis
    - Statistics management
    - Hint usage apropriado
    - Set-based vs row-based approaches
- **Resource Management**
    - Memory allocation
    - CPU utilization
    - I/O optimization
    - Parallelism configuration

**Benchmarks Obrigatórios:**

1. Otimizar consulta de 1M+ registros para <1s
2. Reduzir uso de CPU em 50% mantendo funcionalidade
3. Eliminar deadlocks em ambiente concorrente
4. Otimizar storage para reduzir I/O

**Critério de Aprovação:** Qualquer código deve ter performance production-ready

---

## **Módulo 5.2: Debugging e Troubleshooting (20h)**

**Objetivo:** Resolver qualquer problema rapidamente

**Ferramentas e Técnicas:**

- **Debugging Sistemático**
    - PRINT statements estratégicos
    - Profiler e Extended Events
    - Activity Monitor
    - Custom logging tables
- **Error Analysis**
    - Error message interpretation
    - Stack trace analysis
    - Reprodução de bugs
    - Root cause analysis
- **Testing Strategies**
    - Unit testing para SQL
    - Integration testing
    - Load testing
    - Regression testing

**Casos Práticos:**

1. Debug de deadlock intermitente
2. Resolver memory leak em procedure
3. Identificar query com performance degradada
4. Troubleshoot de data corruption

**Critério de Aprovação:** Resolver qualquer issue em ambiente de produção

---

# **FASE 6: PROJETO CAPSTONE (40-60 horas)**

## **Recriação Completa do Código Original**

**Objetivo:** Implementar solução igual ou superior ao código apresentado

**Requisitos Não-Negociáveis:**

1. **Análise Completa do Código Original (10h)**
    - Decomposição linha por linha
    - Identificação de todos os padrões
    - Mapeamento de lógica de negócio
    - Documentação completa
2. **Reimplementação do Zero (20h)**
    - Estrutura de dados otimizada
    - Algoritmo de redistribuição melhorado
    - Tratamento de erros robusto
    - Performance superior ao original
3. **Extensões e Melhorias (15h)**
    - Interface de configuração
    - Múltiplos algoritmos de redistribuição
    - Relatórios avançados
    - API para integração
4. **Testes e Validação (10h)**
    - Casos de teste abrangentes
    - Performance benchmarks
    - Stress testing
    - Documentação técnica completa
5. **Apresentação e Defesa (5h)**
    - Demonstração ao vivo
    - Explicação de cada decisão técnica
    - Comparação com original
    - Planos de evolução futura

---

# **METODOLOGIA DE ESTUDO**

### **Cronograma Sugerido:**

- **Dedicação:** 15-20h/semana
- **Duração Total:** 4-6 meses
- **Progresso:** Avaliação semanal obrigatória

### **Recursos Obrigatórios:**

- SQL Server Development Edition (gratuito)
- SQL Server Management Studio
- Sample databases (AdventureWorks, Northwind)
- Livros: "SQL Server Query Performance Tuning", "T-SQL Fundamentals"

### **Critérios de Qualidade:**

- **Zero tolerância para código que funciona "mais ou menos"**
- **Todo código deve ter tratamento de erro completo**
- **Performance sempre medida e otimizada**
- **Documentação obrigatória para tudo**

### **Avaliação Final:**

- **Código funcionando 100% sem bugs**
- **Performance superior ao original**
- **Explicação fluente de cada linha**
- **Capacidade de modificar/estender sem assistência**

---

# **RECURSOS COMPLEMENTARES**

### **Prática Diária Obrigatória:**

1. **30 min:** Resolução de problemas SQL online (HackerRank, LeetCode)
2. **30 min:** Leitura técnica (blogs, documentação oficial)
3. **60 min:** Implementação prática dos conceitos estudados

### **Projetos Paralelos Recomendados:**

- Sistema de controle de biblioteca
- E-commerce com gestão de inventory
- Sistema financeiro pessoal
- Analytics de dados de vendas

### **Certificações Alvo:**

- Microsoft Certified: Azure Database Administrator
- Oracle Database SQL Certified Associate
- PostgreSQL Certified Professional

---

# Termos_Conceitos

- O que são constraits?
    
    Neste texto vamos discutir a importância de garantir a integridade dos dados em bancos de dados relacionais usando restrições (Constraints). As tabelas relacionais armazenam dados em várias tabelas relacionadas e as chaves são usadas para criar referências de uma tabela para outra. **Para que o design do banco de dados funcione corretamente, é necessário garantir que apenas dados válidos sejam inseridos nas tabelas e isso é feito usando restrições.** Por fim, as constraints são regras que controlam como os dados do banco de dados são inseridos ou manipulados. Vamos para os tipos de constraints:
    
    **Primary Keys:** Uma chave primária é uma restrição especial usada para garantir que os valores em uma coluna (ou conjunto de colunas) sejam únicos e nunca mudem — em outras palavras, uma coluna (ou colunas) em uma tabela cujos valores identificam exclusivamente cada linha da tabela. Isso facilita a manipulação direta e a interação com linhas individuais. Sem chaves primárias, seria difícil usar com segurança UPDATE ou DELETE em linhas específicas sem afetar nenhuma outra.
    
    **Foreign Keys:** A foreign key is a column in a table whose values must be listed in a primary key in another table. Foreign keys are an extremely important part of ensuring referential integrity.
    
    **Unique Keys:** são usadas para garantir que todos os dados em uma coluna (ou conjunto de colunas) sejam exclusivos. Elas são semelhantes às chaves primárias, mas existem algumas distinções importantes:
    
    - Uma tabela pode conter várias restrições exclusivas, mas apenas uma chave primária é permitida por tabela.
    - Colunas de restrição única de imagem podem conter valores NULL.
    - As colunas de restrição única de imagem podem ser modificadas ou atualizadas.
    - Os valores exclusivos da coluna de restrição de imagem podem ser reutilizados.
    - Ao contrário das chaves primárias, restrições exclusivas não podem ser usadas para definir chaves estrangeiras.
    
    **Check Constraints:** As restrições de verificação são usadas para garantir que os dados em uma coluna (ou conjunto de colunas) atendam a um conjunto de critérios que você especifica. Usos comuns disso são:
    
    - Verificação de valores mínimos ou máximos — Por exemplo, impedindo uma ordem de 0 (zero) itens (mesmo que 0 seja um número válido);
    - Especificando intervalos — Por exemplo, certificando-se de que uma data de envio seja maior ou igual à data de hoje e não maior que um ano a partir de agora;
    - Permitindo apenas valores específicos — Por exemplo, permitindo apenas M ou F em um campo de gênero.
    
    # **Adicionando constraints**
    
    As restrições SQL são regras que restringem o tipo e a quantidade de dados que podem ser inseridos em uma tabela. As restrições podem ser definidas no momento da criação da tabela ou adicionadas posteriormente a uma tabela existente usando o comando **ALTER TABLE**.
    
    As restrições podem ser no nível da coluna ou no nível da tabela, onde as restrições no nível da coluna são aplicadas a uma única coluna e as restrições no nível da tabela são aplicadas à tabela inteira. Veja como adicionar restrições no SQL Server e no Oracle:
    
    No SQL Server, você pode usar o comando **ALTER TABLE** para adicionar restrições a uma tabela existente.
    
    Aqui estão alguns exemplos de como adicionar restrições no SQL Server (também se aplica no Oracle):
    
    ```
    -- Adicionando uma constraint de chave primária em uma tabela:
    ALTER TABLE table_name
    ADD CONSTRAINT constraint_name PRIMARY KEY (column1, column2);
    
    -- Adicionando uma constraint de chave estrangeira em uma tabela:
    ALTER TABLE table_name
    ADD CONSTRAINT constraint_name FOREIGN KEY (column1) REFERENCES other_table_name (column2);
    
    -- Adicionando uma check constraint a uma tabela:
    ALTER TABLE table_name
    ADD CONSTRAINT constraint_name CHECK (column_name > 0);
    
    -- Adicionando uma unique constraint a uma tabela:
    ALTER TABLE table_name
    ADD CONSTRAINT constraint_name UNIQUE (column1, column2);
    ```
    
    *Tanto no SQL Server quanto no Oracle, você também pode adicionar restrições ao criar uma tabela usando o comando CREATE TABLE.*
    
    # **Removendo Constraints**
    
    Para remover uma restrição de uma tabela no SQL Server ou Oracle, você pode usar o comando ALTER TABLE com a cláusula DROP CONSTRAINT seguida do nome da restrição.
    
    A sintaxe é a mesma para SQL Server e Oracle. aqui estão alguns exemplos:
    
    ```
    --Para remover uma restrição denominada constraint_name de uma tabela denominada table_name, use a seguinte instrução SQL:
    ALTER TABLE table_name
    DROP CONSTRAINT constraint_name;
    
    --Por exemplo, para descartar uma restrição de chave primária chamada pk_mytable de uma tabela chamada mytable, use a seguinte instrução:
    ALTER TABLE mytable
    DROP CONSTRAINT pk_mytable;
    ```
    
    # **Uso do CASCADE e SET NULL na remoção de Constraints**
    
    Ao projetar um esquema de banco de dados, é importante configurar as relações de tabela corretamente. Um aspecto disso é definir restrições em chaves estrangeiras, que podem afetar o que acontece quando uma linha na tabela referenciada é excluída ou atualizada. A seguir estão as opções disponíveis para restrições de chave estrangeira no SQL:
    
    **CASCADE**: Se uma linha na tabela referenciada for excluída ou atualizada, a alteração é propagada para a tabela referenciada. Por exemplo, se uma linha for excluída na tabela referenciada, todas as linhas na tabela de referência que fazem referência a essa linha também serão excluídas. Essa opção é útil quando você deseja manter a integridade referencial e garantir que todas as linhas dependentes sejam removidas quando a linha pai for removida. No entanto, também pode levar a consequências não intencionais, como excluir todas as linhas filhas de uma tabela quando uma linha pai é excluída.
    
    **SET NULL**: Se uma linha na tabela de referência for excluída ou atualizada, o valor da coluna na tabela de referência será definido como NULL. Essa opção é útil quando você deseja manter a integridade referencial, mas permite linhas órfãs na tabela de referência. Por exemplo, se você tiver uma tabela de funcionários com uma coluna de chave estrangeira referenciando uma tabela de departamentos, convém definir a coluna de chave estrangeira como NULL quando um departamento for excluído, em vez de excluir todos os funcionários desse departamento.
    
    Abaixo exemplos de comandos usando o CASCADE e SET NULL:
    
    ```
    -- Exemplo de uso do CASCADE
    ALTER TABLE Sales.TempSalesReason
       ADD CONSTRAINT FK_TempSales_SalesReason FOREIGN KEY (TempID)
          REFERENCES Sales.SalesReason (SalesReasonID)
          ON DELETE CASCADE
          ON UPDATE CASCADE
    
    -- Exemplo de uso do SET NULL
    ALTER TABLE employees
    ADD FOREIGN KEY (department_id)
    REFERENCES departments(department_id)
    ON DELETE SET NULL
    ```
    
    # **Uso do CASCADE em casos de remoção de colunas**
    
    O uso de CASCADE ao remover colunas não está relacionado a restrições de chave estrangeira. CASCADE neste contexto refere-se ao efeito em cascata da remoção de uma coluna em outros objetos dependentes, como exibições, procedimentos armazenados ou outras tabelas que fazem referência à coluna que está sendo removida. Quando CASCADE é usado neste contexto, significa que os objetos dependentes também serão automaticamente modificados ou removidos quando a coluna for removida. Por exemplo, se você tiver uma exibição que faz referência a uma coluna que está sendo removida, poderá usar CASCADE para remover automaticamente a exibição junto com a coluna. Aqui está um exemplo de uso de CASCADE ao remover uma coluna no SQL Server:
    
    ```
    ALTER TABLE MyTable
    DROP COLUMN MyColumn
    CASCADE;
    ```
    
    # **Renomeando Constraints**
    
    Existem casos em que precisamos renomear constraints para ter um nome mais amigável (diferente das constraints geradas pelo sistema).
    
    Importante salientar que o nome novo da constraint não deve existir em outras constraints, senão terá conflito e com isso erro em execução do comando.
    
    Um exemplo simples de comandos em SQL Server e Oracle para renomear constraints:
    
    ```
    --Oracle
    ALTER TABLE clients RENAME CONSTRAINT SYS_C00101512 TO not_null_phone;
    
    --SQL Server
    EXEC sp_rename N'schema.old_constraint_name', N'new_constraint_name', N'OBJECT'
    ```
    
    # **Desativando e Ativando Constraints**
    
    Podemos desativar constraints de determinada tabela em casos onde temos interesse de executar operações DDL sem restrições. Em casos onde a constraint é uma PK, não conseguimos desativar visto que tem um FK como referência. Podemos usar a opção CASCADE para desativar a PK constraint e todas FK relacionadas.
    
    No SQL Server, a sintaxe para desativar uma constraint consiste do comando **ALTER TABLE** usando o argumento **NOCHECK.**
    
    ```
    ALTER TABLE BandMember
    NOCHECK CONSTRAINT FK_BandMember_Musician;
    ```
    
    Para verificar se a restrição foi desativada, você pode consultar a exibição do sistema sys.foreign_keys:
    
    ```
    SELECT
      name AS 'Constraint',
      is_disabled,
      is_not_trusted
    FROM sys.foreign_keys;
    ```
    
    Isso mostrará todas as restrições de chave estrangeira no banco de dados atual. A coluna is_disabled indica se a restrição está atualmente desabilitada (1) ou habilitada (0). A coluna is_not_trusted indica se a restrição foi verificada pelo sistema (0) ou não (1). Se precisar reativar a restrição, você pode usar a opção WITH CHECK para restaurar a confiança da restrição.
    
    Para habilitar uma restrição no SQL Server, você pode usar a instrução ALTER TABLE com a opção CHECK CONSTRAINT. Aqui estão exemplos para habilitar uma única restrição e todas as restrições para uma tabela:
    
    ```
    -- Enable single constraint
    ALTER TABLE YourTableName CHECK CONSTRAINT YourConstraint
    
    -- Enable all table constraints
    ALTER TABLE YourTableName CHECK CONSTRAINT ALL
    ```
    
    No Oracle, você pode usar a instrução **ALTER TABLE** para desabilitar ou habilitar restrições. Segue a sintaxe e exemplo:
    
    ```
    --Sintaxe:
    ALTER TABLE <TN> DISABLE / ENABLE CONSTRAINT <CONSTRAINT KEY NAME>;
    
    --Exemplo:
    ALTER TABLE employees DISABLE CONSTRAINT emp_dept_fk;
    ```
    
    Para ativar a restrição, basta substituir DISABLE por ENABLE na instrução acima.
    

# MÓDULO 1.1 - SQL BÁSICO REVISADO (VERSÃO INTENSIVA)
15 horas de estudo rigoroso | Preparação para SQL Avançado

## **OBJETIVOS DE APRENDIZAGEM**

Ao completar este módulo, você será capaz de:

- Criar estruturas de banco complexas sem consultar documentação
- Manipular dados com precisão cirúrgica usando DML avançado
- Compreender profundamente tipos de dados e suas implicações
- Executar operações batch com controle total
- **Critério Final:** Implementar sistema de estoque completo em <2 horas

---

## **SEÇÃO 1: DDL - DATA DEFINITION LANGUAGE (5 horas)**

### **1.1 CREATE TABLE - Dominando Estruturas (2h)**

### **Teoria Essencial:**

Uma tabela não é apenas um container de dados - é uma **estrutura que define regras de negócio**. Cada decisão na criação impacta performance, integridade e manutenibilidade.

### **Sintaxe Completa Dominada:**

```sql
CREATE TABLE nome_tabela (
    coluna1 tipo_dados [IDENTITY(seed,increment)] [NULL|NOT NULL],
    coluna2 tipo_dados [DEFAULT valor_default],
    coluna3 tipo_dados [CHECK (condição)],
    [CONSTRAINT nome_pk PRIMARY KEY (colunas)],
    [CONSTRAINT nome_fk FOREIGN KEY (coluna) REFERENCES tabela(coluna)],
    [CONSTRAINT nome_uk UNIQUE (colunas)],
    [CONSTRAINT nome_ck CHECK (condição_complexa)]
);

```

### **EXERCÍCIO PRÁTICO 1.1A - Sistema Base**

Implemente este sistema de estoque (tempo limite: 45 min):

```sql
-- Sua missão: Criar estas 5 tabelas com todas as constraints necessárias

-- 1. PRODUTOS
-- Colunas: ProdutoID (PK, IDENTITY), Nome (50 chars, obrigatório),
-- Categoria (20 chars), PrecoBase (decimal 10,2), Ativo (bit, default 1)
-- Regra: Nome deve ser único por categoria

-- 2. CORES
-- Colunas: CorID (PK, IDENTITY), Codigo (10 chars, único),
-- Descricao (50 chars), HexColor (7 chars, formato #RRGGBB)
-- Regra: HexColor deve começar com #

-- 3. TAMANHOS
-- Colunas: TamanhoID (PK, IDENTITY), Codigo (10 chars),
-- Descricao (30 chars), OrdemExibicao (int)
-- Regra: OrdemExibicao deve ser > 0

-- 4. SKUS (Stock Keeping Units)
-- Colunas: SKU (PK, VARCHAR(20)), ProdutoID (FK), CorID (FK),
-- TamanhoID (FK), PrecoVenda (decimal 10,2), DataCriacao (datetime, default GETDATE())
-- Regras: SKU formato 'PROD-COR-TAM', PrecoVenda >= PrecoBase do produto

-- 5. ESTOQUE
-- Colunas: EstoqueID (PK, IDENTITY), SKU (FK), Quantidade (int >= 0),
-- QuantidadeReservada (int >= 0), UltimaMovimentacao (datetime)
-- Regra: QuantidadeReservada <= Quantidade

```

### **SOLUÇÃO MODELO - Compare com a sua:**

```sql
-- PRODUTOS
CREATE TABLE PRODUTOS (
    ProdutoID INT IDENTITY(1,1) PRIMARY KEY,
    Nome VARCHAR(50) NOT NULL,
    Categoria VARCHAR(20) NOT NULL,
    PrecoBase DECIMAL(10,2) NOT NULL CHECK (PrecoBase > 0),
    Ativo BIT NOT NULL DEFAULT 1,
    CONSTRAINT UK_Produto_Nome_Categoria UNIQUE (Nome, Categoria)
);

-- CORES
CREATE TABLE CORES (
    CorID INT IDENTITY(1,1) PRIMARY KEY,
    Codigo VARCHAR(10) NOT NULL UNIQUE,
    Descricao VARCHAR(50) NOT NULL,
    HexColor VARCHAR(7) NOT NULL CHECK (HexColor LIKE '#[0-9A-F][0-9A-F][0-9A-F][0-9A-F][0-9A-F][0-9A-F]')
);

-- TAMANHOS
CREATE TABLE TAMANHOS (
    TamanhoID INT IDENTITY(1,1) PRIMARY KEY,
    Codigo VARCHAR(10) NOT NULL UNIQUE,
    Descricao VARCHAR(30) NOT NULL,
    OrdemExibicao INT NOT NULL CHECK (OrdemExibicao > 0)
);

-- SKUS
CREATE TABLE SKUS (
    SKU VARCHAR(20) PRIMARY KEY,
    ProdutoID INT NOT NULL,
    CorID INT NOT NULL,
    TamanhoID INT NOT NULL,
    PrecoVenda DECIMAL(10,2) NOT NULL,
    DataCriacao DATETIME NOT NULL DEFAULT GETDATE(),
    CONSTRAINT FK_SKU_Produto FOREIGN KEY (ProdutoID) REFERENCES PRODUTOS(ProdutoID),
    CONSTRAINT FK_SKU_Cor FOREIGN KEY (CorID) REFERENCES CORES(CorID),
    CONSTRAINT FK_SKU_Tamanho FOREIGN KEY (TamanhoID) REFERENCES TAMANHOS(TamanhoID),
    CONSTRAINT CK_SKU_Formato CHECK (SKU LIKE '[A-Z]%-[A-Z]%-[A-Z]%'),
    -- Esta constraint será implementada via trigger pois requer JOIN
);

-- ESTOQUE
CREATE TABLE ESTOQUE (
    EstoqueID INT IDENTITY(1,1) PRIMARY KEY,
    SKU VARCHAR(20) NOT NULL,
    Quantidade INT NOT NULL DEFAULT 0 CHECK (Quantidade >= 0),
    QuantidadeReservada INT NOT NULL DEFAULT 0 CHECK (QuantidadeReservada >= 0),
    UltimaMovimentacao DATETIME NOT NULL DEFAULT GETDATE(),
    CONSTRAINT FK_Estoque_SKU FOREIGN KEY (SKU) REFERENCES SKUS(SKU),
    CONSTRAINT CK_Reserva_Valida CHECK (QuantidadeReservada <= Quantidade)
);

```

### **AUTO-AVALIAÇÃO CRÍTICA:**

- [ ]  Todas as constraints estão corretas?
- [ ]  Nomes seguem padrão consistente?
- [ ]  Tipos de dados são otimizados para o uso?
- [ ]  Constraint de preço no SKU >= PrecoBase (pendente para triggers)?

---

## **1.2 Tipos de Dados - Decisões Críticas (1h)**

### **Conhecimento Obrigatório:**

**STRINGS:**

- `VARCHAR(n)` vs `CHAR(n)` - Quando usar cada?
- `NVARCHAR` para Unicode - Overhead vs necessidade
- `TEXT` vs `VARCHAR(MAX)` - Depreciação e alternativas

**NÚMEROS:**

- `INT` vs `BIGINT` vs `SMALLINT` - Planejamento de crescimento
- `DECIMAL(p,s)` vs `FLOAT` - Precisão vs performance
- `MONEY` - Quando usar ou evitar

**DATAS:**

- `DATETIME` vs `DATETIME2` vs `DATE` vs `TIME`
- Fusos horários: `DATETIMEOFFSET`
- Precisão necessária vs espaço ocupado

### **EXERCÍCIO CRÍTICO 1.2A - Escolhas Justificadas**

Para cada cenário, escolha o tipo ideal e **justifique**:

1. ID de produto em sistema que pode ter 50 milhões de produtos
2. Código de barras internacional (até 14 dígitos)
3. Preço de produto em e-commerce (precisão centavos)
4. Nome de cliente (internacional, acentos)
5. Timestamp de transação financeira (precisão milissegundos)
6. Status de pedido (5 opções: Pending, Processing, Shipped, Delivered, Cancelled)
7. Coordenadas GPS (latitude/longitude)
8. Hash MD5 de arquivo
9. Comentário de produto (até 2000 caracteres)
10. Contador de visualizações de página (pode chegar a bilhões)

### **RESPOSTAS MODELO:**

1. `BIGINT` - INT limitaria a 2.1B, insuficiente para 50M com crescimento
2. `VARCHAR(14)` - Numérico mas pode ter leading zeros, não fazer cálculos
3. `DECIMAL(10,2)` - Precisão exata necessária para valores monetários
4. `NVARCHAR(100)` - Unicode necessário para nomes internacionais
5. `DATETIME2(3)` - Precisão milissegundos, mais eficiente que DATETIME2(7)
6. `TINYINT` - 5 opções cabem em TINYINT (0-255), usar lookup table
7. `DECIMAL(9,6)` - Precisão de ~1 metro, adequada para maioria dos casos
8. `CHAR(32)` - Tamanho fixo, sempre 32 caracteres hexadecimais
9. `VARCHAR(2000)` - Tamanho variável, sem necessidade de Unicode
10. `BIGINT` - Bilhões requerem BIGINT, INT seria limitante

---

## **1.3 ALTER TABLE - Evolução Estrutural (1h)**

### **Operações Críticas:**

- Adicionar colunas com constraints
- Modificar tipos de dados (compatibilidade)
- Adicionar/remover constraints
- Renomear objetos

### **EXERCÍCIO AVANÇADO 1.3A - Evolução do Sistema**

Evolua o sistema criado anteriormente:

```sql
-- MODIFICAÇÕES OBRIGATÓRIAS:
-- 1. Adicionar coluna 'Descricao' (VARCHAR(500)) na tabela PRODUTOS
-- 2. Modificar PrecoBase para aceitar até 4 casas decimais
-- 3. Adicionar coluna 'Peso' (DECIMAL(8,3)) na tabela SKUS
-- 4. Criar constraint para garantir que Peso > 0
-- 5. Adicionar coluna 'EstoqueMinimo' na tabela ESTOQUE
-- 6. Renomear coluna 'Ativo' para 'Status' na tabela PRODUTOS
-- 7. Adicionar constraint DEFAULT 'ATIVO' para Status

```

### **SOLUÇÃO COM BEST PRACTICES:**

```sql
-- 1. Adicionar Descricao
ALTER TABLE PRODUTOS
ADD Descricao VARCHAR(500) NULL;

-- 2. Modificar PrecoBase (CUIDADO: pode falhar se dados existem)
ALTER TABLE PRODUTOS
ALTER COLUMN PrecoBase DECIMAL(12,4) NOT NULL;

-- 3. Adicionar Peso
ALTER TABLE SKUS
ADD Peso DECIMAL(8,3) NULL;

-- 4. Constraint para Peso
ALTER TABLE SKUS
ADD CONSTRAINT CK_SKU_Peso_Positivo CHECK (Peso IS NULL OR Peso > 0);

-- 5. EstoqueMinimo
ALTER TABLE ESTOQUE
ADD EstoqueMinimo INT NOT NULL DEFAULT 0 CHECK (EstoqueMinimo >= 0);

-- 6 e 7. Renomear e adicionar default (SQL Server)
EXEC sp_rename 'PRODUTOS.Ativo', 'Status', 'COLUMN';
ALTER TABLE PRODUTOS
ADD CONSTRAINT DF_Produto_Status DEFAULT 'ATIVO' FOR Status;

```

---

## **1.4 Constraints - Regras de Negócio em SQL (1h)**

### **Tipos e Aplicações:**

- **PRIMARY KEY** - Identificação única
- **FOREIGN KEY** - Integridade referencial
- **UNIQUE** - Unicidade de valores
- **CHECK** - Validações customizadas
- **DEFAULT** - Valores padrão inteligentes

### **EXERCÍCIO COMPLEXO 1.4A - Constraints Avançadas**

Implemente constraints para estas regras de negócio:

```sql
-- REGRAS A IMPLEMENTAR:
-- 1. SKU deve ter formato específico: LETRA(3)-NUMERO(3)-LETRA(2)
-- 2. Email de cliente deve conter @ e pelo menos um ponto após @
-- 3. Data de nascimento deve ser no passado mas não mais que 120 anos
-- 4. Telefone deve ter formato brasileiro: (XX) XXXXX-XXXX
-- 5. CEP deve ter formato XXXXX-XXX
-- 6. Status de pedido só pode ser: 'NOVO', 'PROCESSANDO', 'ENVIADO', 'ENTREGUE', 'CANCELADO'
-- 7. Percentual de desconto deve estar entre 0 e 100
-- 8. Preço promocional deve ser menor que preço normal

```

### **IMPLEMENTAÇÃO MODELO:**

```sql
-- 1. SKU específico
ALTER TABLE PRODUTOS
ADD CONSTRAINT CK_SKU_Formato
CHECK (SKU LIKE '[A-Z][A-Z][A-Z]-[0-9][0-9][0-9]-[A-Z][A-Z]');

-- 2. Email válido
ALTER TABLE CLIENTES
ADD CONSTRAINT CK_Email_Formato
CHECK (Email LIKE '%@%._%');

-- 3. Data nascimento
ALTER TABLE CLIENTES
ADD CONSTRAINT CK_DataNascimento_Valida
CHECK (DataNascimento < GETDATE() AND DataNascimento > DATEADD(YEAR, -120, GETDATE()));

-- 4. Telefone brasileiro
ALTER TABLE CLIENTES
ADD CONSTRAINT CK_Telefone_Formato
CHECK (Telefone LIKE '([0-9][0-9]) [0-9][0-9][0-9][0-9][0-9]-[0-9][0-9][0-9][0-9]');

-- 5. CEP formato
ALTER TABLE ENDERECOS
ADD CONSTRAINT CK_CEP_Formato
CHECK (CEP LIKE '[0-9][0-9][0-9][0-9][0-9]-[0-9][0-9][0-9]');

-- 6. Status pedido
ALTER TABLE PEDIDOS
ADD CONSTRAINT CK_Status_Valido
CHECK (Status IN ('NOVO', 'PROCESSANDO', 'ENVIADO', 'ENTREGUE', 'CANCELADO'));

-- 7. Desconto percentual
ALTER TABLE PROMOCOES
ADD CONSTRAINT CK_Desconto_Percentual
CHECK (PercentualDesconto >= 0 AND PercentualDesconto <= 100);

-- 8. Preço promocional (esta requer comparison entre colunas)
ALTER TABLE PRODUTOS
ADD CONSTRAINT CK_Preco_Promocional
CHECK (PrecoPromocional IS NULL OR PrecoPromocional < PrecoNormal);

```

---

## **SEÇÃO 2: DML - DATA MANIPULATION LANGUAGE (5 horas)**

### **2.1 INSERT - Inserção Estratégica (2h)**

### **Modalidades de INSERT:**

**1. INSERT Básico:**

```sql
INSERT INTO tabela (col1, col2) VALUES (val1, val2);

```

**2. INSERT Múltiplo (Batch):**

```sql
INSERT INTO tabela (col1, col2)
VALUES (val1a, val2a), (val1b, val2b), (val1c, val2c);

```

**3. INSERT com SELECT:**

```sql
INSERT INTO tabela_destino (col1, col2)
SELECT col1, col2 FROM tabela_origem WHERE condição;

```

**4. INSERT com OUTPUT:**

```sql
INSERT INTO tabela (col1, col2)
OUTPUT INSERTED.ID, INSERTED.col1
VALUES (val1, val2);

```

### **EXERCÍCIO INTENSIVO 2.1A - População do Sistema**

Popule o sistema com dados realistas (tempo: 60 min):

```sql
-- DADOS OBRIGATÓRIOS A INSERIR:

-- 1. PRODUTOS (mínimo 20 produtos, 5 categorias diferentes)
-- Exemplo: Camisetas, Calças, Vestidos, Sapatos, Acessórios

-- 2. CORES (mínimo 15 cores com códigos e hex corretos)
-- Exemplo: Branco (#FFFFFF), Preto (#000000), etc.

-- 3. TAMANHOS (pelo menos 10 tamanhos com ordem lógica)
-- Exemplo: PP(1), P(2), M(3), G(4), GG(5), 36(6), 38(7), etc.

-- 4. SKUS (mínimo 100 SKUs, distribuídos pelos produtos)
-- Use combinações realistas produto+cor+tamanho

-- 5. ESTOQUE (para todos os SKUs, com quantidades variadas)
-- Alguns com estoque zero, outros com reservas

-- REGRAS:
-- - Use transações para garantir consistência
-- - Implemente tratamento de erro
-- - Gere SKUs automaticamente no formato correto
-- - Preços de venda 20-50% acima do preço base

```

### **SOLUÇÃO MODELO - Estrutura Profissional:**

```sql
-- INÍCIO DA TRANSAÇÃO
BEGIN TRY
    BEGIN TRANSACTION;

    -- 1. PRODUTOS
    INSERT INTO PRODUTOS (Nome, Categoria, PrecoBase, Descricao) VALUES
    ('Camiseta Básica', 'Camisetas', 29.90, 'Camiseta de algodão básica'),
    ('Camiseta Premium', 'Camisetas', 49.90, 'Camiseta de algodão premium'),
    ('Polo Clássica', 'Camisetas', 69.90, 'Camisa polo tradicional'),
    ('Calça Jeans Slim', 'Calças', 89.90, 'Calça jeans corte slim'),
    ('Calça Jeans Reta', 'Calças', 79.90, 'Calça jeans corte reto'),
    ('Calça Social', 'Calças', 129.90, 'Calça social executiva'),
    ('Vestido Casual', 'Vestidos', 99.90, 'Vestido casual dia a dia'),
    ('Vestido Festa', 'Vestidos', 199.90, 'Vestido para ocasiões especiais'),
    ('Tênis Casual', 'Calçados', 159.90, 'Tênis para uso casual'),
    ('Sapato Social', 'Calçados', 199.90, 'Sapato social masculino');

    -- 2. CORES
    INSERT INTO CORES (Codigo, Descricao, HexColor) VALUES
    ('BR', 'Branco', '#FFFFFF'),
    ('PT', 'Preto', '#000000'),
    ('AZ', 'Azul', '#0000FF'),
    ('VM', 'Vermelho', '#FF0000'),
    ('VD', 'Verde', '#00FF00'),
    ('AM', 'Amarelo', '#FFFF00'),
    ('RS', 'Rosa', '#FFC0CB'),
    ('CZ', 'Cinza', '#808080'),
    ('MR', 'Marrom', '#8B4513'),
    ('BG', 'Bege', '#F5F5DC');

    -- 3. TAMANHOS
    INSERT INTO TAMANHOS (Codigo, Descricao, OrdemExibicao) VALUES
    ('PP', 'Extra Pequeno', 1),
    ('P', 'Pequeno', 2),
    ('M', 'Médio', 3),
    ('G', 'Grande', 4),
    ('GG', 'Extra Grande', 5),
    ('36', 'Tamanho 36', 6),
    ('38', 'Tamanho 38', 7),
    ('40', 'Tamanho 40', 8),
    ('42', 'Tamanho 42', 9),
    ('44', 'Tamanho 44', 10);

    -- 4. SKUS (usando cursor para gerar automaticamente)
    DECLARE @ProdutoID INT, @CorID INT, @TamanhoID INT;
    DECLARE @PrecoBase DECIMAL(10,2), @PrecoVenda DECIMAL(10,2);
    DECLARE @CodCor VARCHAR(10), @CodTamanho VARCHAR(10);
    DECLARE @SKUGerado VARCHAR(20);

    DECLARE cursor_produtos CURSOR FOR
    SELECT ProdutoID, PrecoBase FROM PRODUTOS;

    OPEN cursor_produtos;
    FETCH NEXT FROM cursor_produtos INTO @ProdutoID, @PrecoBase;

    WHILE @@FETCH_STATUS = 0
    BEGIN
        -- Para cada produto, criar SKUs para todas as combinações cor/tamanho viáveis
        DECLARE cursor_cores CURSOR FOR
        SELECT CorID, Codigo FROM CORES WHERE CorID <= 5; -- Limitando cores para exemplo

        OPEN cursor_cores;
        FETCH NEXT FROM cursor_cores INTO @CorID, @CodCor;

        WHILE @@FETCH_STATUS = 0
        BEGIN
            DECLARE cursor_tamanhos CURSOR FOR
            SELECT TamanhoID, Codigo FROM TAMANHOS WHERE TamanhoID <= 5; -- Limitando tamanhos

            OPEN cursor_tamanhos;
            FETCH NEXT FROM cursor_tamanhos INTO @TamanhoID, @CodTamanho;

            WHILE @@FETCH_STATUS = 0
            BEGIN
                -- Gerar SKU no formato correto
                SET @SKUGerado = 'PRD-' + RIGHT('000' + CAST(@ProdutoID AS VARCHAR), 3) +
                                '-' + @CodCor + '-' + @CodTamanho;

                -- Calcular preço de venda (20-50% acima do base)
                SET @PrecoVenda = @PrecoBase * (1.2 + (RAND() * 0.3));

                INSERT INTO SKUS (SKU, ProdutoID, CorID, TamanhoID, PrecoVenda)
                VALUES (@SKUGerado, @ProdutoID, @CorID, @TamanhoID, @PrecoVenda);

                FETCH NEXT FROM cursor_tamanhos INTO @TamanhoID, @CodTamanho;
            END;

            CLOSE cursor_tamanhos;
            DEALLOCATE cursor_tamanhos;

            FETCH NEXT FROM cursor_cores INTO @CorID, @CodCor;
        END;

        CLOSE cursor_cores;
        DEALLOCATE cursor_cores;

        FETCH NEXT FROM cursor_produtos INTO @ProdutoID, @PrecoBase;
    END;

    CLOSE cursor_produtos;
    DEALLOCATE cursor_produtos;

    -- 5. ESTOQUE (para todos os SKUs criados)
    INSERT INTO ESTOQUE (SKU, Quantidade, QuantidadeReservada, EstoqueMinimo)
    SELECT
        SKU,
        ABS(CHECKSUM(NEWID())) % 100 + 1, -- Quantidade aleatória 1-100
        ABS(CHECKSUM(NEWID())) % 10,      -- Reserva aleatória 0-9
        10                                 -- Estoque mínimo padrão
    FROM SKUS;

    -- Ajustar reservas que excedem quantidade
    UPDATE ESTOQUE
    SET QuantidadeReservada = Quantidade
    WHERE QuantidadeReservada > Quantidade;

    COMMIT TRANSACTION;
    PRINT 'Dados inseridos com sucesso!';

END TRY
BEGIN CATCH
    ROLLBACK TRANSACTION;
    PRINT 'Erro na inserção: ' + ERROR_MESSAGE();
END CATCH;

```

---

## **2.2 UPDATE - Modificação Precisa (1.5h)**

### **Padrões de UPDATE:**

**1. UPDATE Simples:**

```sql
UPDATE tabela SET coluna = valor WHERE condição;
```

**2. UPDATE com JOIN:**

```sql
UPDATE t1
SET t1.coluna = t2.valor
FROM tabela1 t1
INNER JOIN tabela2 t2 ON t1.id = t2.id
WHERE condição;
```

**3. UPDATE com Subconsulta:**

```sql
UPDATE tabela
SET coluna = (SELECT valor FROM outra_tabela WHERE condição)
WHERE EXISTS (SELECT 1 FROM outra_tabela WHERE condição);
```

### **EXERCÍCIO CRÍTICO 2.2A - Atualizações Complexas**

Execute estas atualizações no sistema (45 min):

```sql
-- ATUALIZAÇÕES OBRIGATÓRIAS:

-- 1. Atualizar preços de todos os produtos da categoria 'Camisetas'
--    com aumento de 15%

-- 2. Zerar estoque de todos os SKUs que não tiveram movimentação
--    nos últimos 30 dias

-- 3. Atualizar status de produtos para 'INATIVO' quando
--    soma do estoque de todos os seus SKUs for zero

-- 4. Recalcular preço de venda dos SKUs para ser exatamente
```

---